# Command Line Interface (CLI) tool

This project is a Command Line Interface (CLI) tool for file manipulation and directory navigation, inspired by Unix-like operating systems. The tool includes various commands to perform common file and directory operations.

## Setup

1. Ensure Python 3.8 or higher is installed on your system.
2. Clone the repository or download the script.
3. Run the tool using the provided commands.

## Usage

List Directory Contents (`list`):

```bash
python Python_basic_finalproject_Fateme_Mohamadrezaie.py change [path]
python Python_basic_finalproject_Fateme_Mohamadrezaie.py make [path]
python Python_basic_finalproject_Fateme_Mohamadrezaie.py remove_dir [path]
python Python_basic_finalproject_Fateme_Mohamadrezaie.py remove_file [file]
python Python_basic_finalproject_Fateme_Mohamadrezaie.py remove_dir_rec [directory]
python Python_basic_finalproject_Fateme_Mohamadrezaie.py copy [source] [destination]
python Python_basic_finalproject_Fateme_Mohamadrezaie.py move [source] [destination]
python Python_basic_finalproject_Fateme_Mohamadrezaie.py find_files [path] [pattern]
python Python_basic_finalproject_Fateme_Mohamadrezaie.py display_file [file]
python Python_basic_finalproject_Fateme_Mohamadrezaie.py touch [file]
python Python_basic_finalproject_Fateme_Mohamadrezaie.py system_info
python Python_basic_finalproject_Fateme_Mohamadrezaie.py search_content [file] [search_term]
python Python_basic_finalproject_Fateme_Mohamadrezaie.py rename_file [old_name] [new_name]

```

### Arguments

- list: List directory contents
- change: Change the working directory
- make: Create a new directory
- delete_dir: Remove an empty directory
- delete_file: Remove a file
- delete_dir_rec: Remove a directory and its contents recursively
- copy: Copy a file or directory
- move: Move a file or directory
- find_files: Search for files or directories
- display_file: Output the contents of a file
- create_empty_file: Create an empty file
- system_info: Display system information
- search_file_content: Search for content within a file
- rename_file: Rename a file

## Logs

Logs of the executed commands are stored in `python_basic_finalproject_fateme_mohamadrezaie_logs.txt`, with each entry timestamped.

---

Thanks!
