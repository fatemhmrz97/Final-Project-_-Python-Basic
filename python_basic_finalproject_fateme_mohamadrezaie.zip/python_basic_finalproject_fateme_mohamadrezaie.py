import os
import shutil
import argparse
from datetime import datetime

# Function to log commands and their outcomes
def log_command(command, args, outcome):
    log_entry = f"{datetime.now()} - Command: {command} {args} - Outcome: {outcome}\n"
    with open("python_basic_finalproject_fateme_mohamadrezaie_logs.txt", "a") as log_file:
        log_file.write(log_entry)

# Command functions
def list_contents_cmd(args):
    path = args.path or os.getcwd()
    try:
        files = os.listdir(path)
        print("\n".join(files))
        log_command("list_contents", f"Path: {path}", "Success")
    except Exception as e:
        print(f"Error: {e}")
        log_command("list_contents", f"Path: {path}", f"Error - {e}")

def change_directory_cmd(args):
    path = args.path or os.path.expanduser("~")
    try:
        os.chdir(path)
        print("Current directory:", os.getcwd())
        log_command("change_directory", f"Path: {path}", "Success")
    except Exception as e:
        print(f"Error: {e}")
        log_command("change_directory", f"Path: {path}", f"Error - {e}")

def create_directory_cmd(args):
    try:
        os.makedirs(args.path, exist_ok=True)
        print("Directory created:", args.path)
        log_command("create_directory", f"Path: {args.path}", "Success")
    except Exception as e:
        print(f"Error: {e}")
        log_command("create_directory", f"Path: {args.path}", f"Error - {e}")

def delete_directory_cmd(args):
    try:
        os.rmdir(args.path)
        print("Directory removed:", args.path)
        log_command("delete_directory", f"Path: {args.path}", "Success")
    except Exception as e:
        print(f"Error: {e}")
        log_command("delete_directory", f"Path: {args.path}", f"Error - {e}")

def delete_file_cmd(args):
    try:
        os.remove(args.file)
        print("File removed:", args.file)
        log_command("delete_file", f"File: {args.file}", "Success")
    except Exception as e:
        print(f"Error: {e}")
        log_command("delete_file", f"File: {args.file}", f"Error - {e}")

def delete_directory_recursive_cmd(args):
    try:
        shutil.rmtree(args.directory)
        print("Directory removed recursively:", args.directory)
        log_command("delete_directory_recursive", f"Directory: {args.directory}", "Success")
    except Exception as e:
        print(f"Error: {e}")
        log_command("delete_directory_recursive", f"Directory: {args.directory}", f"Error - {e}")

def copy_cmd(args):
    try:
        if os.path.isfile(args.source):
            shutil.copy(args.source, args.destination)
            print("File copied:", args.source, "->", args.destination)
        elif os.path.isdir(args.source):
            shutil.copytree(args.source, args.destination)
            print("Directory copied:", args.source, "->", args.destination)
        log_command("copy", f"Source: {args.source}, Destination: {args.destination}", "Success")
    except Exception as e:
        print(f"Error: {e}")
        log_command("copy", f"Source: {args.source}, Destination: {args.destination}", f"Error - {e}")

def move_cmd(args):
    try:
        shutil.move(args.source, args.destination)
        print("Moved:", args.source, "->", args.destination)
        log_command("move", f"Source: {args.source}, Destination: {args.destination}", "Success")
    except Exception as e:
        print(f"Error: {e}")
        log_command("move", f"Source: {args.source}, Destination: {args.destination}", f"Error - {e}")

def find_files_cmd(args):
    try:
        for root, dirs, files in os.walk(args.path):
            for name in files + dirs:
                if args.pattern in name:
                    print(os.path.join(root, name))
        log_command("find_files", f"Path: {args.path}, Pattern: {args.pattern}", "Success")
    except Exception as e:
        print(f"Error: {e}")
        log_command("find_files", f"Path: {args.path}, Pattern: {args.pattern}", f"Error - {e}")

def display_file_content_cmd(args):
    try:
        with open(args.file, "r") as file:
            content = file.read()
            print(content)
        log_command("display_file_content", f"File: {args.file}", "Success")
    except Exception as e:
        print(f"Error: {e}")
        log_command("display_file_content", f"File: {args.file}", f"Error - {e}")

def create_empty_file_cmd(args):
    try:
        with open(args.file, "w"):
            pass
        print("File created:", args.file)
        log_command("create_empty_file", f"File: {args.file}", "Success")
    except Exception as e:
        print(f"Error: {e}")
        log_command("create_empty_file", f"File: {args.file}", f"Error - {e}")

def system_info_cmd(args):
    try:
        # Add system information retrieval logic here
        print("System information will be displayed here.")
        log_command("system_info", "", "Success")
    except Exception as e:
        print(f"Error: {e}")
        log_command("system_info", "", f"Error - {e}")

def search_file_content(file_path, search_term):
    try:
        with open(file_path, "r") as file:
            content = file.read()
            if search_term in content:
                print(f"Search term '{search_term}' found in file '{file_path}'")
            else:
                print(f"Search term '{search_term}' not found in file '{file_path}'")
    except Exception as e:
        print(f"Error: {e}")
        log_command("search_file_content", f"File: {file_path}, Search Term: {search_term}", f"Error - {e}")

def rename_file_cmd(args):
    try:
        os.rename(args.old_name, args.new_name)
        print("File renamed:", args.old_name, "->", args.new_name)
        log_command("rename_file", f"Old Name: {args.old_name}, New Name: {args.new_name}", "Success")
    except Exception as e:
        print(f"Error: {e}")
        log_command("rename_file", f"Old Name: {args.old_name}, New Name: {args.new_name}", f"Error - {e}")

def main():
    # Set up the argument parser
    parser = argparse.ArgumentParser(description="Command Line Interface (CLI) tool for file manipulation and directory navigation.")
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Add parsers for each command
    list_dir_parser = subparsers.add_parser("list", help="List directory contents")
    list_dir_parser.add_argument("path", nargs="?", default=None, help="Path to the directory (optional)")

    change_dir_parser = subparsers.add_parser("change", help="Change working directory")
    change_dir_parser.add_argument("path", nargs="?", default=None, help="Path to the directory (optional)")

    make_dir_parser = subparsers.add_parser("make", help="Create a new directory")
    make_dir_parser.add_argument("path", help="Path to the new directory")

    delete_dir_parser = subparsers.add_parser("delete_dir", help="Remove an empty directory")
    delete_dir_parser.add_argument("path", help="Path to the directory to be removed")

    delete_file_parser = subparsers.add_parser("delete_file", help="Remove a file")
    delete_file_parser.add_argument("file", help="File to be removed")

    delete_dir_rec_parser = subparsers.add_parser("delete_dir_rec", help="Remove a directory and its contents recursively")
    delete_dir_rec_parser.add_argument("directory", help="Directory to be removed recursively")

    copy_parser = subparsers.add_parser("copy", help="Copy a file or directory")
    copy_parser.add_argument("source", help="Source file or directory")
    copy_parser.add_argument("destination", help="Destination path")

    move_parser = subparsers.add_parser("move", help="Move a file or directory")
    move_parser.add_argument("source", help="Source file or directory")
    move_parser.add_argument("destination", help="Destination path")

    find_files_parser = subparsers.add_parser("find_files", help="Search for files or directories")
    find_files_parser.add_argument("path", help="Starting path for the search")
    find_files_parser.add_argument("pattern", help="Pattern to search for")

    display_file_parser = subparsers.add_parser("display_file", help="Output the contents of a file")
    display_file_parser.add_argument("file", help="File to display")

    create_empty_file_parser = subparsers.add_parser("create_empty_file", help="Create an empty file")
    create_empty_file_parser.add_argument("file", help="Path to the new file")

    system_info_parser = subparsers.add_parser("system_info", help="Display system information")

    search_file_content_parser = subparsers.add_parser("search_file_content", help="Search for content within a file")
    search_file_content_parser.add_argument("file", help="File to search within")
    search_file_content_parser.add_argument("search_term", help="Search term")

    rename_file_parser = subparsers.add_parser("rename_file", help="Rename a file")
    rename_file_parser.add_argument("old_name", help="Old name of the file")
    rename_file_parser.add_argument("new_name", help="New name of the file")

    args = parser.parse_args()

    # Execute the appropriate command function
    if args.command:
        globals()[f"{args.command}_cmd"](args)

if __name__ == "__main__":
    main()
